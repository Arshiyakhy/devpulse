import { Hono } from "hono";
import { users } from "@devpulse/db";
type Variables = {
    user: typeof users.$inferSelect;
};
declare const app: Hono<{
    Variables: Variables;
}, import("hono/types").BlankSchema, "/">;
export { app };
//# sourceMappingURL=index.d.ts.map